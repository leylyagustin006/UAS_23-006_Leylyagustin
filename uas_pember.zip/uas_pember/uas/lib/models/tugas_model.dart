class Tugas {
  final String id;
  final String judul;
  final String kategori;
  final String deadline;
  bool selesai;

  Tugas({
    required this.id,
    required this.judul,
    required this.kategori,
    required this.deadline,
    this.selesai = false,
  });

  // Untuk konversi dari Map (misal dari Firebase Realtime Database)
  factory Tugas.fromJson(Map<String, dynamic> json, String id) {
    return Tugas(
      id: id,
      judul: json['judul'] ?? '',
      kategori: json['kategori'] ?? '',
      deadline: json['deadline'] ?? '',
      selesai: json['selesai'] ?? false,
    );
  }

  // Untuk simpan ke Firebase
  Map<String, dynamic> toJson() {
    return {
      'judul': judul,
      'kategori': kategori,
      'deadline': deadline,
      'selesai': selesai,
    };
  }
}
