import 'package:firebase_database/firebase_database.dart';
import 'package:uuid/uuid.dart';
import '../models/tugas_model.dart';

class TugasService {
  final DatabaseReference _database = FirebaseDatabase.instance.ref().child('tugas');

  // Ambil semua data tugas
  Future<List<Tugas>> getSemuaTugas() async {
    final snapshot = await _database.get();
    if (snapshot.exists) {
      final data = Map<String, dynamic>.from(snapshot.value as Map);
      return data.entries.map((e) {
        return Tugas.fromJson(Map<String, dynamic>.from(e.value), e.key);
      }).toList();
    } else {
      return [];
    }
  }

  // Tambah tugas baru
  Future<void> tambahTugas(Tugas tugas) async {
    final id = const Uuid().v4();
    await _database.child(id).set(tugas.toJson());
  }

  // Update tugas (edit atau checklist selesai)
  Future<void> updateTugas(Tugas tugas) async {
    await _database.child(tugas.id).update(tugas.toJson());
  }

  // Hapus tugas
  Future<void> hapusTugas(String id) async {
    await _database.child(id).remove();
  }

  // Ambil detail tugas berdasarkan ID
  Future<Tugas?> getTugasById(String id) async {
    final snapshot = await _database.child(id).get();
    if (snapshot.exists) {
      return Tugas.fromJson(Map<String, dynamic>.from(snapshot.value as Map), id);
    }
    return null;
  }
}
