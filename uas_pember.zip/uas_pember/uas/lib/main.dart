// Nama Lengkap: Leyly Agustin
// NIM: 230441100006
// Kelas: PEMBER C
// Nama Asprak: Kak Kukuh Cokro Wibowo

import 'package:flutter/material.dart';
import 'screens/home.dart';

void main() {
  runApp(ToDoListApp());
}

class ToDoListApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do List Mahasiswa',
      theme: ThemeData(
        primaryColor: Color(0xFF1A1A50),
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: Color(0xFF0F3C61),
        ),
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Poppins',
      ),
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}
