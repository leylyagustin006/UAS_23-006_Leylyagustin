import 'package:flutter/material.dart';
import '../models/tugas_model.dart';
import 'tambah.dart';
import 'detail.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Tugas> daftarTugas = [
    Tugas(
      id: '1',
      judul: 'Tugas Pemrograman Bergerak',
      kategori: 'Kuliah',
      deadline: '31 Mei 2025',
      selesai: false,
    ),
    Tugas(
      id: '2',
      judul: 'Laporan Akhir Pember',
      kategori: 'Kuliah',
      deadline: '1 Juni 2025',
      selesai: false,
    ),
    Tugas(
      id: '3',
      judul: 'Rapat Organisasi',
      kategori: 'Organisasi',
      deadline: '1 Juni 2025',
      selesai: false,
    ),
  ];

  String filterKategori = 'All';

  @override
  Widget build(BuildContext context) {
    List<Tugas> filteredTugas = filterKategori == 'All'
        ? daftarTugas
        : daftarTugas
            .where((tugas) => tugas.kategori == filterKategori)
            .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('To-Do List Mahasiswa'),
        backgroundColor: const Color.fromARGB(255, 251, 251, 252),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: DropdownButton<String>(
              value: filterKategori,
              items: ['All', 'Kuliah', 'Organisasi']
                  .map((kategori) => DropdownMenuItem(
                        value: kategori,
                        child: Text(kategori),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  filterKategori = value!;
                });
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredTugas.length,
              itemBuilder: (context, index) {
                final tugas = filteredTugas[index];
                return Card(
                  margin: const EdgeInsets.symmetric(
                      horizontal: 16.0, vertical: 8.0),
                  color: const Color(0xFFB0D4DB),
                  child: ListTile(
                    title: Text(tugas.judul),
                    subtitle: Text('Deadline: ${tugas.deadline}\n${tugas.kategori}'),
                    trailing: Checkbox(
                      value: tugas.selesai,
                      onChanged: (value) {
                        setState(() {
                          tugas.selesai = value!;
                        });
                      },
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => DetailTugasScreen(tugas: tugas),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF1A1A50),
        onPressed: () async {
          final newTugas = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => TambahTugasScreen()),
          );
          if (newTugas != null && newTugas is Tugas) {
            setState(() {
              daftarTugas.add(newTugas);
            });
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
