import 'package:flutter/material.dart';
import '../models/tugas_model.dart';

class TambahTugasScreen extends StatefulWidget {
  const TambahTugasScreen({super.key});

  @override
  State<TambahTugasScreen> createState() => _TambahTugasScreenState();
}

class _TambahTugasScreenState extends State<TambahTugasScreen> {
  final _formKey = GlobalKey<FormState>();
  String judul = '';
  String kategori = 'Kuliah';
  String deadline = '';
  // Gambar tidak digunakan dulu (bonus)

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Data'),
        backgroundColor: const Color.fromARGB(255, 248, 248, 249),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text("Judul Tugas:"),
              TextFormField(
                onChanged: (value) => judul = value,
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: Color(0xFFB0D4DB),
                ),
              ),
              const SizedBox(height: 16),
              const Text("Kategori:"),
              DropdownButtonFormField<String>(
                value: kategori,
                items: ['Kuliah', 'Organisasi']
                    .map((k) => DropdownMenuItem(value: k, child: Text(k)))
                    .toList(),
                onChanged: (value) => kategori = value!,
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: Color(0xFFB0D4DB),
                ),
              ),
              const SizedBox(height: 16),
              const Text("Deadline:"),
              TextFormField(
                onChanged: (value) => deadline = value,
                decoration: const InputDecoration(
                  hintText: 'cth: 2 Juni 2025',
                  filled: true,
                  fillColor: Color(0xFFB0D4DB),
                ),
              ),
              const SizedBox(height: 16),
              const Text("Gambar Pendukung:"),
              Container(
                height: 100,
                width: 100,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF1A1A50)),
                ),
                child: const Icon(Icons.camera_alt, size: 40),
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1A1A50),
                ),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    final tugas = Tugas(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      judul: judul,
                      kategori: kategori,
                      deadline: deadline,
                      selesai: false,
                    );
                    Navigator.pop(context, tugas);
                  }
                },
                child: const Text("Simpan"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
