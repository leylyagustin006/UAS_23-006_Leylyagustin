import 'package:flutter/material.dart';
import '../models/tugas_model.dart';

class DetailTugasScreen extends StatelessWidget {
  final Tugas tugas;

  const DetailTugasScreen({super.key, required this.tugas});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Tugas'),
        backgroundColor: const Color.fromARGB(255, 247, 247, 248),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildField("Judul Tugas:", tugas.judul),
            _buildField("Kategori:", tugas.kategori),
            _buildField("Deadline:", tugas.deadline),
            _buildField("Keterangan:", tugas.selesai ? "Sudah Selesai" : "Belum Selesai"),
            const SizedBox(height: 20),
            const Text("Gambar Pendukung:"),
            const SizedBox(height: 10),
            Container(
              height: 150,
              width: 150,
              decoration: BoxDecoration(
                border: Border.all(),
                image: const DecorationImage(
                  image: AssetImage('assets/images/default.jpg'), // placeholder
                  fit: BoxFit.cover,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildField(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label),
        const SizedBox(height: 4),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          color: const Color(0xFFB0D4DB),
          child: Text(value),
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}
